% CONSTANT
g = 9.81;

% Uncertain friction
mu = 0.17; % Varies: 0.11 - 0.17
ST_gram = 130; % Vary proportionally? Reseasrch: correlation between stat and dyn coeffs.

% Masses (kg)
m_prop = 6 / 1000;
m_motor = 76 / 1000;
m_esc = 42 / 1000;
m_des = 90 / 1000;
m_cw = 0 / 1000;

% Lengths (m)
l_T = 14.5 / 1000 + 24/1000;
l_g = 10 / 1000 + 24/1000;
l_c = 5.5 / 100;
h = 21.04 / 100;

% Gains for tuning OLD
P1 = 5;
I1 = 4;
D1 = 0.1;

P2 = 0.5;
I2 = 0.2;
D2 = 0;

clegg = 0.5;